package Actividades.Actividad17;

public interface Sonoro {
    public void emitirSonido();
}
