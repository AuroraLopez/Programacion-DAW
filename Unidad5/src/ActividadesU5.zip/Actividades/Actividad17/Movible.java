package Actividades.Actividad17;

public interface Movible {
    public void mover();
}
