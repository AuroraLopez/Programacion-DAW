package Actividades.Tarea2;

public interface Identificacion {
    public void identificarse();
}
