public class Actividad2 {
    public static void main(String[] args) {
      /*
      * 2. (2 puntos) Implementa la función obtenerVector(array, num), donde obtengas como salida un
      * array que en cada posición tiene la suma de los num elementos consecutivos. Tienes que verificar
      * que num es un número menor que el tamaño del vector. Ejemplo para un array que tiene
      * {10,1,5,8,9,2} y num=3, el resultado saldría {16, 14, 22, 19}, donde 16= (10+1+5), 14=(1+5+8),
      * 22=(5+8+9) y 19=(8+9+2). El array de salida se genera como array dinámico.
      */  
    }
}
