public class Actividad5 {
    public static boolean esPrimo(int n){
        if (n<2) {
            return false;
        }
        else{
            return true;
        }
    }
    public static void main(String[] args) {
        /*
         * Siguiendo este pseudocódigo, genera la función que pasado un número nos diga
         * si es
         * primo o no.
         * Algoritmo EsPrimo (n)
         * Definir esPrimo como Lógico
         * Si n < 2 Entonces
         * devolver esPrimo ← Falso
         * Sino
         * Programación
         * Examen de recuperación primer trimestre
         * esPrimo ← Verdadero
         * Para i=2 Hasta n-1 Hacer
         * Si n % i = 0 Entonces
         * devolver esPrimo ← Falso
         * FinSi
         * FinPara
         * FinSi
         * devolver esPrimo ← Verdadero
         * FinAlgoritmo
         * Una vez lo tengas, usa esa función para obtener los números primos que hay
         * entre dos números
         * introducidos por teclado por el usuario (numero1 y numero2). Tienes que
         * comprobar que estos dos
         * números siempre tienen que ser mayores que 50 y que numero1 es menor que
         * numero2.
         */
    }
}
