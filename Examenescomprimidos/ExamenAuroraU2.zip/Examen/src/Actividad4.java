public class Actividad4 {
    public static int EsPrimo(int n){
        if(n<2){
            return 0;
        }
        else{
            return 1;
        }
    }
    public static void main(String[] args) {
        /*
         * Siguiendo este pseudocódigo, genera la función que pasado un número nos diga si es 
         * primo o no.
         */
    }
}
