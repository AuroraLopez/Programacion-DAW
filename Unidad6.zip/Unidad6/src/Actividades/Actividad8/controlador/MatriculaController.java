package Actividades.Actividad8.controlador;

import Actividades.Actividad9.modelo.MatriculaDAO;
import Actividades.Actividad9.modelo.ProfesorDAO;
import Actividades.Actividad9.vista.MatriculaView;

public class MatriculaController {
    private ProfesorDAO profesordao;
    private MatriculaDAO matriculadao;
    private MatriculaView matriculaview;

    public MatriculaController() {
        profesordao = new ProfesorDAO();
        matriculadao = new MatriculaDAO();
        matriculaview = new MatriculaView();
    }

    public void iniciar() {
        int opcion;
        try{
            do {
                opcion = matriculaview.mostrarMenu();
                switch (opcion) {
                    case 1: matriculaview.mostrarProfesor(profesordao.listar());
                        matriculaview.mostrarMensaje("Listando el contenido de Profesor..."); break;
                    case 2: profesordao.insertar(matriculaview.pedirNuevoProfesor());
                        matriculaview.mostrarMensaje("Añadiendo profesor..."); break;
                    case 3: profesordao.actualizar(matriculaview.pedirProfesorActualizar());
                        matriculaview.mostrarMensaje("Actualizando profesor..."); break; 
                    case 4: profesordao.eliminar(matriculaview.pedirIdEliminar());
                        matriculaview.mostrarMensaje("Borrando profesor..."); break;
                    case 5: matriculadao.insertar(matriculaview.pedirNuevaMatricula());
                        matriculaview.mostrarMensaje("Añadiendo matricula..."); break;
                    case 0: matriculaview.mostrarMensaje("Saliendo..."); break;
                    default: matriculaview.mostrarMensaje("Opción incorrecta"); break;
                }
            } while (opcion != 0);
        }catch(Exception e){
            System.err.println(e.getStackTrace());
        }
    }
}
