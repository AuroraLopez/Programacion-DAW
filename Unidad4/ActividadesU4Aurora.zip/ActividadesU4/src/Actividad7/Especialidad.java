package Actividad7;

public enum Especialidad {
    FRENOS,HIDRÁULICA,ELECTRIDAD,MOTOR;
}
