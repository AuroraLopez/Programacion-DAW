import Clases.Batalla;

public class Main {
    public static void main(String[] args) {
        Batalla batalla = new Batalla();
        batalla.mostrarmenu();
    }
}
