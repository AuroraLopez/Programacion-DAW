package Clases;

public enum Tipo {
    CABALLERO, MAGO, ORCO
}
