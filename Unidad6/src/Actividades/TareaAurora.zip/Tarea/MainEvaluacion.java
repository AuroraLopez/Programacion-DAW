package Actividades.Tarea;

import Actividades.Tarea.controlador.EvaluacionController;

public class MainEvaluacion {
    public static void main(String[] args) {
        new EvaluacionController().iniciar();
    }
}
