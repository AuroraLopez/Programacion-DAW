package Actividad8;

public interface Volador{
    public void volar();
}
